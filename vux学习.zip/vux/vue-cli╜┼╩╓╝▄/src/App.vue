<!--根组件-->
<template>
  <div id="app">


    <view-box>

      <router-view/>
      <tabbar>
        <tabbar-item selected badge="99+" link="/">
          <i slot="icon" class="fa fa-qq"></i>
          <span slot="label">QQ</span>
        </tabbar-item>
        <tabbar-item link="/index">
          <i slot="icon" class="fa fa-wechat"></i>
          <span slot="label">WeChat</span>
        </tabbar-item>
        <tabbar-item link="/hhh">
          <i slot="icon" class="fa fa-facebook-official"></i>
          <span slot="label">Facebook</span>
        </tabbar-item>
        <tabbar-item>
          <i slot="icon" class="fa fa-twitter"></i>
          <span slot="label">Twitter</span>
        </tabbar-item>
      </tabbar>
    </view-box>
  </div>
</template>

<script>
  import { ViewBox,Tabbar,TabbarItem } from 'vux'
  export default {
      name:'App',
    components:{
      ViewBox,
      Tabbar,
      TabbarItem,
    }
  }
</script>

<style lang="less">
  /*引入默认样式重置*/
  @import '~vux/src/styles/reset.less';
  html,body{
    height: 100%;
    width: 100%;
    overflow-x: hidden;
  }
  #app{
    height: 100%;
    .my-tab{
      width: 400px;
    }
  }

</style>
