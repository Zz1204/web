<template>
  <div class="app">
    <!-- viewBox 就是整个手机的大盒子 -->
    <view-box>
      <x-header class="my-head" :left-options="{showBack:true,backText:'返回',preventGoBack:false}">
        <div>hellowrld</div>
        <div slot="right" class="fa fa-share-alt"></div>
      </x-header>
      <sc class='my-sc' :lock-y="true">
        <div class="my-tab">
          <tab :line-width='3' class="my-tab1">
            <tab-item selected @on-item-click="onItemClick">科技</tab-item>
            <tab-item @on-item-click="onItemClick">娱乐</tab-item>
            <tab-item @on-item-click="onItemClick">影视</tab-item>
            <tab-item @on-item-click="onItemClick">音乐</tab-item>
          </tab>
        </div>
      </sc>
      <scroller ref="scr" class="scro" refreshText="loading" :on-refreshText="refresh" :on-infinite="infinite">
        <swiper :list="list" auto loop></swiper>
        <marquee style="text-align: center">
          <marquee-item v-for="i in 3" :key="i" class="align-middle">hello world {{i}}</marquee-item>
        </marquee>
        <panel class="imag" :list="datas"></panel>
      </scroller>
    </view-box>
  </div>
</template>

<script>
  // 引入 viewBox
  import {ViewBox,XHeader,Tab, TabItem,Tabbar,TabbarItem,Scroller as sc,Swiper,Marquee, MarqueeItem,Panel} from 'vux'
  export default {
    data(){
      return{
        list:[
          { url: 'javascript:', img: 'https://static.vux.li/demo/1.jpg', title: '送你一朵fua' },
          { url: 'javascript:', img: 'https://static.vux.li/demo/2.jpg', title: '送你一次旅行'},
          { url: 'javascript:', img: 'https://static.vux.li/demo/3.jpg', title: '送你一朵fua' },
          { url: 'javascript:', img: 'https://static.vux.li/demo/2.jpg', title: '送你一次旅行'},
        ],
        datas:[{
          src: 'https://static.vux.li/demo/1.jpg',
          fallbackSrc: 'http://placeholder.qiniudn.com/60x60/3cc51f/ffffff',
          title: '标题一',
          desc: '由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。',
          url: '/component/cell'
        }, {
          src: 'https://static.vux.li/demo/2.jpg',
          title: '标题二',
          desc: '由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。',
          url: {
            path: '/component/radio',
            replace: false
          },
          meta: {
            source: '来源信息',
            date: '时间',
            other: '其他信息'
          }
        },
          {
            src: 'https://static.vux.li/demo/1.jpg',
            fallbackSrc: 'http://placeholder.qiniudn.com/60x60/3cc51f/ffffff',
            title: '标题一',
            desc: '由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。',
            url: '/component/cell'
          },{
            src: 'https://static.vux.li/demo/1.jpg',
            fallbackSrc: 'http://placeholder.qiniudn.com/60x60/3cc51f/ffffff',
            title: '标题一',
            desc: '由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。',
            url: '/component/cell'
          },{
            src: 'https://static.vux.li/demo/1.jpg',
            fallbackSrc: 'http://placeholder.qiniudn.com/60x60/3cc51f/ffffff',
            title: '标题一',
            desc: '由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。',
            url: '/component/cell'
          },{
            src: 'https://static.vux.li/demo/1.jpg',
            fallbackSrc: 'http://placeholder.qiniudn.com/60x60/3cc51f/ffffff',
            title: '标题一',
            desc: '由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。',
            url: '/component/cell'
          },{
            src: 'https://static.vux.li/demo/1.jpg',
            fallbackSrc: 'http://placeholder.qiniudn.com/60x60/3cc51f/ffffff',
            title: '标题一',
            desc: '由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。',
            url: '/component/cell'
          },{
            src: 'https://static.vux.li/demo/1.jpg',
            fallbackSrc: 'http://placeholder.qiniudn.com/60x60/3cc51f/ffffff',
            title: '标题一',
            desc: '由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。',
            url: '/component/cell'
          },{
            src: 'https://static.vux.li/demo/1.jpg',
            fallbackSrc: 'http://placeholder.qiniudn.com/60x60/3cc51f/ffffff',
            title: '标题一',
            desc: '由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。',
            url: '/component/cell'
          }],
      }

    },
    name: 'app',
    //注册组件
    components:{
      ViewBox,
      XHeader,
      Tab,
      TabItem,
      Tabbar,
      TabbarItem,
      sc,
      Swiper,
      Marquee,
      MarqueeItem,
      Panel
    },
    methods:{
      refresh(){

      },
      infinite(){
      //  表示通知框架加载完成
      //   this.$refs.scr.finishInfinite();
      },
      onItemClick (index) {
        console.log('on item click:', index)
      },
    }
  }

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped  lang="less">
  @import '~vux/src/styles/reset.less';
  html,body{
    height: 100%;
    width: 100%;
    overflow-x: hidden;
  }
  .app{
    height: 100%;
    .my-tab{
      width: 400px;
      .my-tab1{
        width: 415px;
      }
    }

  }
  /*.imag img{*/
     /*height: 60px;*/
   /*}*/
 .weui-panel__bd{
   position: relative !important;
   padding-bottom: 53px !important;
   /*margin-bottom: 90px;*/
 }
  /*.my-head{*/
  /*margin-bottom: 45px;*/
  /*}*/
  .my-sc{
    /*margin-bottom: 45px;*/
  }
</style>
