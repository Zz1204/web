<template>
    <div class="app">
      <view-box>
        <x-header :left-options="{showBack:true,backText:'返回',preventGoBack:false}">
          <div>weixin</div>
          <div slot="right" class="fa fa-share-alt"></div>
        </x-header>



      </view-box>
    </div>
</template>
<style scoped  lang="less">
  @import '~vux/src/styles/reset.less';
  html,body{
    height: 100%;
    width: 100%;
    overflow-x: hidden;
  }
  .app{
    height: 100%;
   .my-tab{
     width: 400px;
    }
  }
</style>
<script>

      import { ViewBox,XHeader,Tab, TabItem,Tabbar,TabbarItem,Scroller } from 'vux'
      export default {
        name: 'app',
        //注册组件
        components: {
          ViewBox,
          XHeader,
          Tab,
          TabItem,
          Tabbar,
          TabbarItem,
          Scroller
        },
        methods:{

          onItemClick (index) {
            console.log('on item click:', index)
          },
        }
      }
</script>
