//入口文件
// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.


//引入Vue模块
import Vue from 'vue'
//引入根组件
import App from './App'
//引入路由
import router from './router'
//引入i18n
import vuei18n from 'vue-i18n'
//使用i18n
Vue.use(vuei18n)
//字体图标库
import 'font-awesome/css/font-awesome.min.css'
//上拉加载下拉刷新的插件
import vueScroller from 'vue-scroller'
Vue.use(vueScroller);
//规定一些代码风格
Vue.config.productionTip = false

/* eslint-disable no-new */
//创建vue对象
new Vue({
  el: '#app',
  router,
  //私有注入根组件
  components: { App },
  //模版
  template: '<App/>'
})

