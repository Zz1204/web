import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'
import Index from '@/components/index'
import Hhh from '@/components/hhh'

//一定要使用use 加载插件
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'HelloWorld',
      component: HelloWorld
    },
    {
      path:'/index',
      name: 'Index',
      component: Index
    },
    {
      path:'/hhh',
      name:'hhh',
      component:Hhh
    }
  ]
})
